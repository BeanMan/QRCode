//
//  ViewController.m
//  downLoadDemo
//
//  Created by bean on 16/2/23.
//  Copyright © 2016年 com.xile. All rights reserved.
//

#import "ViewController.h"
#import <AVFoundation/AVFoundation.h>

@interface ViewController ()<AVCaptureMetadataOutputObjectsDelegate>
{
    AVCaptureVideoPreviewLayer * _preViewLayer;
    AVCaptureSession * _session;
    
}

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    NSArray * arr = @[@"扫一扫",@"生成二维码"];
    for (int i = 0; i<2; i++)
    {
        UIButton * btn = [UIButton buttonWithType:UIButtonTypeCustom];
        btn.frame = CGRectMake(100*i, 100, 90, 90);
        btn.backgroundColor = [UIColor redColor];
        [btn addTarget:self action:@selector(click:) forControlEvents:UIControlEventTouchUpInside];
        btn.tag = i+1;
        [btn setTitle:arr[i] forState:UIControlStateNormal];
        [self.view addSubview:btn];
    }
    
    
}


-(void)click:(UIButton*)btn
{
    if (btn.tag == 1)
    {
        AVCaptureDevice*device = [AVCaptureDevice defaultDeviceWithMediaType:AVMediaTypeVideo];
        
        AVCaptureDeviceInput*input = [AVCaptureDeviceInput deviceInputWithDevice:device error:nil];
        
        AVCaptureMetadataOutput*output = [[AVCaptureMetadataOutput alloc]init];
        
        [output setMetadataObjectsDelegate:self queue:dispatch_get_main_queue()];
        
        _session= [[AVCaptureSession alloc]init];
        
        [_session addInput:input];
        
        [_session addOutput:output];
        
        //设置源设置输出数据类型
        
        [output setMetadataObjectTypes:@[AVMetadataObjectTypeQRCode]];
        
        _preViewLayer= [[AVCaptureVideoPreviewLayer alloc]initWithSession:_session];
        
        _preViewLayer.frame=self.view.bounds;
        
        [self.view.layer addSublayer:_preViewLayer];
        
        [_session startRunning];
    }
    else
    {
        [self createCIImageWithText:@"aaaaaa"];
    }
}

#pragma mark 扫描二维码delegate
- (void)captureOutput:(AVCaptureOutput*)captureOutput didOutputMetadataObjects:(NSArray*)metadataObjects fromConnection:(AVCaptureConnection*)connection

{
    
    [_session stopRunning];
    
    [_preViewLayer removeFromSuperlayer];
    
    if(metadataObjects.count>0) {
        
        NSString*string = [[metadataObjects lastObject]stringValue];
        
//        self.label.text= string;
        NSLog(@"%@",string);
        
    }
    
}

#pragma mark 生成二维码
- (void)createCIImageWithText:(NSString*)text

{
    
    CIFilter*filter = [CIFilter filterWithName:@"CIQRCodeGenerator"];
    
    NSString*string = text;
    
    NSData*data = [string dataUsingEncoding:NSUTF8StringEncoding];
    
    //2.通过kVO设置滤镜传入数据
    
    [filter setValue:data forKey:@"inputMessage"];
    
    //3.生成二维码
    
    CIImage*iconImage = [filter outputImage];
    
    UIImageView*tempImageView = [[UIImageView alloc]initWithFrame:(CGRectMake(50,50,200,200))];
    
    UIImage*image = [UIImage imageWithCIImage:iconImage];
    
    tempImageView.image= image;
    
    [self.view addSubview:tempImageView];
    
}

@end
